const express=require('express')
const cors=require('cors')
const mysql2=require('mysql2')

const app = express();
app.use(express.json());

app.use(cors());

const mysqlConn=mysql2.createConnection({
    host:'127.0.0.1',
    user:'root',
    password:'root',
    database:'dbt'
})

mysqlConn.connect((err)=>{
    if(err){
        console.log("Error occured: "+err);
    }else{
        console.log("connected to database");
    }
})

//showing all user details
app.get('/user',(req,res)=>{
    const sql="Select * from user";
    mysqlConn.query(sql,(err,data)=>{
        if(err) return res.json(err);
        return res.json(data);
    })
})


//create an employee
app.post('/user/create',(req,res)=>{
    const {name,gender,dob}=req.body;
    const sql="insert into user(name,gender,dob) values(?,?,?)";
    mysqlConn.query(sql,[name,gender,dob],(err,result)=>{
        if(err) return res.json(err);
        console.log(result);
        return res.json({message:"User Added Successfully ",id:result.insertId});
    })
})



app.listen(5000,()=>{
    console.log("Server is running on port 5000");
})