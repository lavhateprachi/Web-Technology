import React, { useState } from "react"
import AddUser from "./components/AddUser"
import ListUser from "./components/ListUser"

function App() {
  const [users, setUser] = useState([])

  const handleAddUser = (newUser) => {
    setUser([...users, newUser])
  }

  return (
    <div className="App">
      <h1>User Management App</h1>
      <AddUser onAdd={handleAddUser} />
      <ListUser users={users} />
    </div>
  )
}

export default App
