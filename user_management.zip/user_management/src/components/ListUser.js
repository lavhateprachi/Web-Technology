import React from "react"

const ListUser = ({ users }) => {
  return (
    <div>
      <h2>User List</h2>
      <ul>
        {users.map((user, index) => (
          <li key={index}>
            <strong>{user.Username}</strong> <strong>{user.Gender}</strong> - {user.date}
          </li>
        ))}
      </ul>
    </div>
  )
}

export default ListUser
