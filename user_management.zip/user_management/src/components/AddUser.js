import React, { useState } from "react"

const AddUser = ({ onAdd }) => {
  const [Username, setUsername] = useState("")
  const [Gender, setGender] = useState("")
  const [date, setDate] = useState("")

  const handleSubmit = (e) => {
    e.preventDefault()
    if (!Username || !Gender || !date) return

    onAdd({ Username, Gender, date })
    setUsername("")
    setGender("")
    setDate("")
  }

  return (
    <div>
      <h2>Add User</h2>
      <form onSubmit={handleSubmit}>
        <input
          type="text"
          placeholder="Username"
          value={Username}
          onChange={(e) => setUsername(e.target.value)}
        />
        <input type="text" placeholder="Gender" value={Gender} onChange={(e) => setGender(e.target.value)} />
        <input type="date" value={date} onChange={(e) => setDate(e.target.value)} />
        <button type="submit">Add</button>
      </form>
    </div>
  )
}

export default AddUser
