import React, { useState } from 'react';
import AddEvent from './AddEvent';
import EventList from './EventList';

function App() {
  const [events, setEvents] = useState([]);

  const handleAddEvent = (newEvent) => {
    setEvents([...events, newEvent]);
  };

  return (
    <div className="App">
      <h1>Event Management App</h1>
      <AddEvent onAdd={handleAddEvent} />
      <EventList events={events} />
    </div>
  );
}

export default App;