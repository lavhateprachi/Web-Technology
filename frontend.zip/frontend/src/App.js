import React, { useEffect, useState } from "react";
import { Link, Route, BrowserRouter as Router, Routes } from "react-router-dom";
import Create from "./Create";

import './app.css';

const App = () => {
  const [data, setData] = useState([]);
  useEffect(() => {
    fetch("http://localhost:5000/user")
      .then((res) => res.json())
      .then((data) => setData(data))
      .catch((err) => console.log(err));
  }, []);

  return (
    <Router>
      <div>
        <h1 id="user">User Details</h1>
        <Routes>
          <Route path="/" element={<Home data={data} />} />
          <Route path="/user/create" element={<Create />} />
          
        </Routes>
      </div>
    </Router>
  );
};

const Home = ({ data }) => {
  return (
    <div>
      <table border={4}>
        <thead>
          <th>ID</th>
          <th>Name</th>
          <th>Gender</th>
          <th>Date Of Birth</th>
          <th>OPRATIONS</th>
        </thead>
        <tbody>
          {data.map((d, i) => (
            <tr key={i}>
              <td>{d.id}</td>
              <td>{d.name}</td>
              <td>{d.gender}</td>
              <td>{d.dob}</td>
              <td>
                <Link key={`update-${i}`} to={`employee/update/${d.id}`}>
                  Update 
                </Link>
                <Link key={`delete-${i}`} to={`employee/delete/${d.id}`}
                > Delete</Link>
              </td>
            </tr>
          ))}
        </tbody>
        <tr>
          <td colSpan="4">
            <Link to="user/create">Add User</Link>
          </td>
        </tr>
      </table>
    </div>
  );
};

export default App;
