// import "./App.css";
// import React, { useEffect, useState } from "react";

// const List=()=>{
//     const[users,setUsers]=useState([]);

//     useEffect(()=>{
//         fetch("http://localhost:5000/getusers")
//         .then((res)=>res.json())
//         .then((data)=>setUsers(data))
//         .catch((err)=>console.error(err))
//     },[]);
//     return(
//         <div className="usetTable">
//         <table>
//             <thead>
//                 <th>ID</th>
//                 <th>User Name</th>
//                 <th>Gender</th>
//                 <th>Birth Date</th>
//             </thead>
//             <tbody>
//                 {
//                     users.map((user=>{
//                         return(
//                             <tr key={user.id}>
//                                 <td>{user.id}</td>
//                                 <td>{user.userName}</td>
//                                 <td>{user.gender}</td>
//                                 <td>{user.dob}</td>
//                             </tr>
//                         )
//                     }))
//                 }
//             </tbody>
//         </table>
//         </div>
//     )
// }

// export default List;




