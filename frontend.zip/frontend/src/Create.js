import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";

const Create = () => {
  const navigate=useNavigate();
  const [user, setUser] = useState({
    name: "",
    gender: "",
    dob: "",
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setUser((prevUser) => ({
      ...prevUser,
      [name]: value,
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const response = await fetch("http://localhost:5000/user/create", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(user),
      });

      const data = await response.json();

      console.log("Server response:", data);
      navigate("/")
    } catch (error) {
      console.error("Error:", error);
    }
  };

  return (
    <div>
      <h2>Create User</h2>
      <form onSubmit={handleSubmit}>
        <label>
          Name:
          <input
            type="text"
            name="name"
            value={user.name}
            onChange={handleChange}
          />
        </label>

        <label>
          Gender:
          <input
            type="text"
            name="gender"
            value={user.gender}
            onChange={handleChange}
          />
        </label>

        <label>
          Date Of Birth:
          <input
            type="date"
            name="dob"
            value={user.dob}
            onChange={handleChange}
          />
        </label>

        <button type="submit">Submit</button>
      </form>
      <Link to="/">
        <h3>Home</h3>
      </Link>
    </div>
  );
};

export default Create;

/**This line uses the setEmployee function to update the employee state.
 *  It takes the previous state (prevEmployee) and creates a new object with the same properties (...prevEmployee)
 *  and updates the property specified by name with the new value.

In simpler terms, when you type in an input field, the handleChange function is called.
 It extracts the name and value of the input field and updates the corresponding property in the employee 
 state. This ensures that the component's state always reflects the current values of the form inputs, 
 making them controlled components 
 Dynamic Property ([name]: value): The dynamic property name ([name]) is used to update the property 
 specified by the name variable with the new value. This allows us to update the correct property in 
 the employee state based on the input field's name.*/